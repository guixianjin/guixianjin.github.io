

#### Dependency:

The code is built with following libraries

+ CUDA 10.1
+ python 3.8.3
+ pytorch  1.7.1
+ torchvision  0.8.2
+ progress 1.5

#### Datasets:

+ CIFAR-10 and CIFAR-100 will be automatically download when the code is running.
+ Webvision can be downloaded from [WebVision](https://data.vision.ee.ethz.ch/cvl/webvision/dataset2017.html).

#### Training:

We provide the training examples with this repo:

- for experiments on CIFAR-10: `sh run_cifar_10.sh`
- for experiments on CIFAR-100: `sh run_cifar_100.sh`

#### Running Environment:

The experimental results reported in paper are conducted on two NVIDIA GeForce RTX 2080 Ti with CUDA 10.1.

#### Contact:

If you have any problem about our code, feel free to contact [guixianjin@126.com](mailto:guixianjin@126.com)